package br.ufsm.poli.csi.redes;

import br.ufsm.poli.csi.redes.swing.ChatClientSwing;

import java.net.UnknownHostException;

public class Main {
    public static void main(String[] args) throws UnknownHostException {
        new ChatClientSwing();

    }
}
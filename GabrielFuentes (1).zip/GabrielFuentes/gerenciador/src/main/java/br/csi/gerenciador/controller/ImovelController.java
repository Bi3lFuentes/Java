package br.csi.gerenciador.controller;


import br.csi.gerenciador.model.imovel.Imovel;
import br.csi.gerenciador.service.ImovelService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/imovel")
@Tag(name="imovel", description = "tag para operações imovel")
public class ImovelController {

    private ImovelService service;

    public ImovelController(ImovelService service) {
        this.service = service;
    }

    @GetMapping("/listar") //@GetMapping: Lida com requisições HTTP do tipo GET, usadas para buscar ou recuperar dados.
    @Operation(summary = "Lista os imóveis", description = "Exibe os imóveis armazenados nas lista")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Imovel listado com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Imovel.class))),
            @ApiResponse(responseCode = "400", description = "Erro de requisição", content = @Content)
    })
    public List<Imovel> listar() {
        return this.service.listar();
    }

    @GetMapping("/uuid/{uuid}")
    //@GetMapping mapeia este método para lidar com requisições HTTP do tipo GET para o caminho /imovel/id
    @Operation(summary = "Busca Imovel pelo UUID", description = "Recupera um imovel usando seu UUID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Imovel encontrado",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Imovel.class))),
            @ApiResponse(responseCode = "404", description = "Imovel não encontrado", content = @Content)
    })
    public Imovel imovel(@PathVariable String uuid) {

        return this.service.getImovelUUID(uuid);
    }

    @GetMapping("/id")
    @Operation(summary = "Busca Imovel pelo ID", description = "Recupera um imovel usando ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Imovel encontrado",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Imovel.class))),
            @ApiResponse(responseCode = "404", description = "Imovel não encontrado", content = @Content)
    })
    //@GetMapping mapeia este método para lidar com requisições HTTP do tipo GET para o caminho /inquilino/id
    public Imovel imovel(@PathVariable Long id) {
        return this.service.getImovel(id);
    }

    @PostMapping("/print-json")
    //@PostMapping mapeia este método para lidar com requisições HTTP do tipo POST no caminho /imovel/print-json
    public void printJson(@RequestBody String json) { //@RequestBody String json: Esta anotação indica que o método espera que o corpo da requisição (request body) contenha dados em formato JSON (ou outro formato textual), e esses dados serão mapeados para a variável json
        System.out.println(json);
    }


    @PostMapping("/salvar")
    @Operation(summary = "Criar novo imovel", description = "Cria novo imovel e adiciona à lista")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Imovel criado com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Imovel.class))),
            @ApiResponse(responseCode = "400", description = "Os dados fornecidos são inválidos", content = @Content)
    })
    public ResponseEntity salvar(@RequestBody @Valid Imovel imovel, UriComponentsBuilder uriBuilder) {

        this.service.salvar(imovel);

        URI uri = uriBuilder.path("/imovel/uuid/{uuid}").buildAndExpand(imovel.getUuid()).toUri();

        return ResponseEntity.created(uri).body(imovel);
    }

    @PutMapping
    @Transactional
    @Operation(summary = "Atualiza um Imovel", description = "Atualiza as informações de um imóvel existente")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Imovel atualizado com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Imovel.class))),
            @ApiResponse(responseCode = "404", description = "Imovel não encontrado", content = @Content)
    })
    public ResponseEntity atualizar(@RequestBody Imovel imovel) {
        this.service.atualizar(imovel);
        return ResponseEntity.ok(imovel);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deleta imovel", description = "remove imovel da lista")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Imovel deletado com sucesso",
                    content = @Content),
            @ApiResponse(responseCode = "400", description = "Erro de requisição", content = @Content),
            @ApiResponse(responseCode = "404", description = "Imovel nao encontrado", content = @Content)
    })
    public void deletar(@PathVariable Long id) {
        this.service.excluir(id);
    }

    // Novo endpoint para associar um Responsavel a um Imovel
    @PostMapping("/{imovelId}/responsavel/{responsavelId}")
    @Operation(summary = "Associa Responsável ao Imovel", description = "Associa um responsável a um imóvel existente")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Responsável associado ao Imovel com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Imovel.class))),
            @ApiResponse(responseCode = "404", description = "Imovel ou Responsável não encontrado", content = @Content),
            @ApiResponse(responseCode = "400", description = "Dados inválidos para associação", content = @Content)
    })
    public ResponseEntity<Imovel> addResponsavelToImovel(@PathVariable Long imovelId, @PathVariable Long responsavelId) {
        try {
            Imovel imovel = this.service.addResponsavelToImovel(imovelId, responsavelId);
            return ResponseEntity.ok(imovel);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build(); // Retorna 404 se não encontrar o Imovel ou Responsavel
        }

    }
}

package br.csi.gerenciador.controller;


import br.csi.gerenciador.model.inquilino.Inquilino;
import br.csi.gerenciador.service.InquilinoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.transaction.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // Informa ao Spring que esta classe irá manipular requisições HTTP.Combina @Controller e @ResponseBody, tornando todas as respostas JSON ou XML automaticamente.
@RequestMapping("/inquilino") // @RequestMapping("/inquilino"): Mapeia uma classe ou método para uma URL específica. No exemplo, /inquilino seria o caminho base para todas as requisições HTTP tratadas pela classe ou pelos métodos anotados.
@Tag(name = "Inquilino", description = "Path para as operações inquilino")
public class InquilinoController {

    private InquilinoService service;

    public InquilinoController(InquilinoService service) {
        this.service = service;
    }

    @GetMapping("/listar") //@GetMapping: Lida com requisições HTTP do tipo GET, usadas para buscar ou recuperar dados.
    @Operation(summary = "Lista os inquilinos", description = "Exibe os inquilinos armazenados nas lista")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Inquilino listado com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Inquilino.class))),
            @ApiResponse(responseCode = "400", description = "Erro de requisição", content = @Content)
    })
    public List<Inquilino> listar() {
        return this.service.listar();
    }

    @GetMapping("/uuid/{uuid}")
    //@GetMapping mapeia este método para lidar com requisições HTTP do tipo GET para o caminho /inquilino/id
    @Operation(summary = "Busca Inquilino pelo UUID", description = "Recupera um inquilino usando seu UUID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Inquilino encontrado",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Inquilino.class))),
            @ApiResponse(responseCode = "404", description = "Inquilino não encontrado", content = @Content)
    })
    public Inquilino inquilino(@PathVariable String uuid) {

        return this.service.getInquilinoUUID(uuid);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Busca Inquilino pelo ID", description = "Recupera um inquilino usando seu ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Inquilino encontrado",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Inquilino.class))),
            @ApiResponse(responseCode = "404", description = "Inquilino não encontrado", content = @Content)
    })
    //@GetMapping mapeia este método para lidar com requisições HTTP do tipo GET para o caminho /inquilino/id
    public Inquilino inquilino(@PathVariable Long id) {
        return this.service.getInquilino(id);
    }

    @PostMapping("/print-json")
    //@PostMapping mapeia este método para lidar com requisições HTTP do tipo POST no caminho /inquilino/print-json
    public void printJson(@RequestBody String json) { //@RequestBody String json: Esta anotação indica que o método espera que o corpo da requisição (request body) contenha dados em formato JSON (ou outro formato textual), e esses dados serão mapeados para a variável json
        System.out.println(json);
    }


    @PostMapping("/salvar")
    @Operation(summary = "Criar novo inquilino", description = "Cria novo inquilino e adiciona à lista")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Inquilino criado com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Inquilino.class))),
            @ApiResponse(responseCode = "400", description = "Os dados fornecidos são inválidos", content = @Content)
    })
    public void salvar(@RequestBody Inquilino inquilino){
        this.service.salvar(inquilino);
    }

    @PutMapping
    @Transactional
    @Operation(summary = "Atualiza um Inquilino", description = "Atualiza as informações de um inquilino existente")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Inquilino atualizado com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Inquilino.class))),
            @ApiResponse(responseCode = "404", description = "Inquilino não encontrado", content = @Content)
    })
    public void atualizar(@RequestBody Inquilino inquilino){
        this.service.atualizar(inquilino);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deleta Inquilino", description = "remove inquilino da tabela")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Inquilino deletado com sucesso",
                    content = @Content),
            @ApiResponse(responseCode = "400", description = "Erro de requisição", content = @Content),
            @ApiResponse(responseCode = "404", description = "Inquilino nao encontrado", content = @Content)
    })
    public void deletar(@PathVariable Long id){
        this.service.excluir(id);
    }

}
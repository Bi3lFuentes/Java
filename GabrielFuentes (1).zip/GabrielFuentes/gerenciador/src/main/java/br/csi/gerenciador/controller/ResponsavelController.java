package br.csi.gerenciador.controller;


import br.csi.gerenciador.model.responsavel.Responsavel;
import br.csi.gerenciador.service.ResponsavelService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.transaction.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController // Informa ao Spring que esta classe irá manipular requisições HTTP.Combina @Controller e @ResponseBody, tornando todas as respostas JSON ou XML automaticamente.
@RequestMapping("/responsavel") // @RequestMapping("/responsavel"): Mapeia uma classe ou método para uma URL específica. No exemplo, /Responsavel seria o caminho base para todas as requisições HTTP tratadas pela classe ou pelos métodos anotados.
@Tag(name = "Responsavel", description = "Path para as operações responsavel")
public class ResponsavelController {

    private ResponsavelService service;

    public ResponsavelController(ResponsavelService service) {
        this.service = service;
    }

    @GetMapping("/listar") //@GetMapping: Lida com requisições HTTP do tipo GET, usadas para buscar ou recuperar dados.
    @Operation(summary = "Lista os responsaveis", description = "Exibe os responsaveis armazenados na tabela")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Responsavel listado com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Responsavel.class))),
            @ApiResponse(responseCode = "400", description = "Erro de requisição", content = @Content)
    })
    public List<Responsavel> listar() {
        return this.service.listar();
    }

    @GetMapping("/uuid/{uuid}")
    //@GetMapping mapeia este método para lidar com requisições HTTP do tipo GET para o caminho /responsavel/id
    @Operation(summary = "Busca Inquilino pelo UUID", description = "Recupera um responsavel usando seu UUID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Responsavel encontrado",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Responsavel.class))),
            @ApiResponse(responseCode = "404", description = "Responsavel não encontrado", content = @Content)
    })
    public Responsavel responsavel(@PathVariable String uuid) {
        return this.service.getResponsavelUUID(uuid);
    }

    @GetMapping("/id")
    @Operation(summary = "Busca Responsavel pelo ID", description = "Recupera um responsavel usando ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Responsavel encontrado",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Responsavel.class))),
            @ApiResponse(responseCode = "404", description = "Responsavel não encontrado", content = @Content)
    })
    //@GetMapping mapeia este método para lidar com requisições HTTP do tipo GET para o caminho /responsavel/id
    public Responsavel responsavel(@PathVariable Long id) {
        return this.service.getResponsavel(id);
    }

    @PostMapping("/print-json")
    //@PostMapping mapeia este método para lidar com requisições HTTP do tipo POST no caminho /responsavel/print-json
    public void printJson(@RequestBody String json) { //@RequestBody String json: Esta anotação indica que o método espera que o corpo da requisição (request body) contenha dados em formato JSON (ou outro formato textual), e esses dados serão mapeados para a variável json
        System.out.println(json);
    }


    @PostMapping("/salvar")
    @Operation(summary = "Criar novo responsavel", description = "Cria novo responsavel pelo imovel e adiciona à lista")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Responsavel criado com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Responsavel.class))),
            @ApiResponse(responseCode = "400", description = "Os dados fornecidos são inválidos", content = @Content)
    })
    public void salvar(@RequestBody Responsavel responsavel){
        this.service.salvar(responsavel);
    }

    @PutMapping
    @Transactional
    @Operation(summary = "Atualiza um Responsavel", description = "Atualiza as informações de um responsavel existente")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Responsavel atualizado com sucesso",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = Responsavel.class))),
            @ApiResponse(responseCode = "404", description = "Responsavel não encontrado", content = @Content)
    })
    public void atualizar(@RequestBody Responsavel responsavel)
    {
        this.service.atualizar(responsavel);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deleta Responsavel", description = "remove responsavel da tabela")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Responsavel deletado com sucesso",
                    content = @Content),
            @ApiResponse(responseCode = "400", description = "Erro de requisição", content = @Content),
            @ApiResponse(responseCode = "404", description = "Responsavel nao encontrado", content = @Content)
    })
    public void deletar(@PathVariable Long id)
    {
        this.service.excluir(id);
    }

}

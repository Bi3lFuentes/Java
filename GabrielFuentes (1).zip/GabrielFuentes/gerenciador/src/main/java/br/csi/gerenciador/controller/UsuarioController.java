package br.csi.gerenciador.controller;


import br.csi.gerenciador.model.usuario.DadosUsuario;
import br.csi.gerenciador.model.usuario.Usuario;
import br.csi.gerenciador.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {
    private final UsuarioService service;
    public UsuarioController(UsuarioService service){
        this.service = service;
    }
    @PostMapping
    @Transactional
    public ResponseEntity criar(@RequestBody @Valid Usuario usuario, UriComponentsBuilder uriBuilder){
        this.service.cadastrar(usuario);
        URI uri = uriBuilder.path("/usuario/{id}").buildAndExpand(usuario.getId()).toUri();
        return ResponseEntity.created(uri).body(usuario);
    }


    @DeleteMapping("/{id}")
    @Operation(summary = "Deleta usuário", description = "remove usuário da lista")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Usuário deletado com sucesso",
                    content = @Content),
            @ApiResponse(responseCode = "400", description = "Erro de requisição", content = @Content),
            @ApiResponse(responseCode = "404", description = "Usuário nao encontrado", content = @Content)
    })
    public void deletar(@PathVariable Long id) {
        this.service.excluir(id);
    }

    @GetMapping("/{id}")
    public DadosUsuario findById(@PathVariable Long id){
        return this.service.findUsuario(id);
    }
    @GetMapping
    public List<DadosUsuario> findAll(){
        return this.service.findAllUsuarios();
    }


}

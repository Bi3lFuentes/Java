package br.csi.gerenciador.model.imovel;

import br.csi.gerenciador.model.inquilino.Inquilino;
import br.csi.gerenciador.model.responsavel.Responsavel;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;

import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "Imoveis")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
public class Imovel {

    @Id @GeneratedValue(
            strategy =
                    GenerationType.IDENTITY)
    @Schema(description = "ID do imóvel", example = "1")
    private Long id;

    @UuidGenerator
    private UUID uuid;

    @NonNull
    @Schema(description = "Rua do imóvel", example = "Floriano Peixoto")
    private String rua;

    @NonNull
    @Schema(description = "Bairro do imóvel", example = "Centro")
    private String bairro;

    @NonNull
    @Schema(description = "Cidade", example = "Santa Maria")
    private String cidade;

    @NonNull
    @Schema(description = "número do imóvel", example = "248")
    private int numero;

    @NonNull
    @Schema(description = "Complemento do imóvel", example = "Bloco A, Apto 201")
    private String complemento;

    @NonNull
    @Schema(description = "Tipo do imóvel", example = "Casa ou Apartamento")
    private String tipo;

    @NonNull
    @Schema(description = "Número de quartos do imóvel", example = "3")
    private int quartos;

    @NonNull
    @Schema(description = "Número de banheiros do imóvel", example = "2")
    private int banheiros;

    @NonNull
    @Schema(description = "Número de vagas de garagem", example = "0")
    private int vagas_garagem;

    @NonNull
    @Schema(description = "Alugado", example = "true")
    private boolean alugado;

    @ManyToOne // Define que um imóvel pode ter um inquilino
    @JoinColumn(name = "inquilino_id", referencedColumnName = "id") // Define a chave estrangeira
    @Schema(description = "Inquilino responsável pelo imóvel")
    private Inquilino inquilino;  // Relacionamento com a entidade Inquilino

    // Relacionamento N para N com Responsavel
    @ManyToMany
    @JsonIgnoreProperties("imoveis")
    @JoinTable(
            name = "Imoveis_Responsavel",
            joinColumns = @JoinColumn(name = "imovel_id"),
            inverseJoinColumns = @JoinColumn(name = "responsavel_id")
    )
    private List<Responsavel> responsaveis;

}

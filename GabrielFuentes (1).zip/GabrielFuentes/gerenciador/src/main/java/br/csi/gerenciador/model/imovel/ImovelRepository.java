package br.csi.gerenciador.model.imovel;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface ImovelRepository extends JpaRepository<Imovel, Long> {

    public Imovel findImovelByUuid(UUID uuid);

    public void deleteImovelByUuid(UUID uuid);
}

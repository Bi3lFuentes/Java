package br.csi.gerenciador.model.inquilino;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;

import java.util.UUID;

@Entity
@Table(name = "Inquilinos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
public class Inquilino {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "ID do inquilino", example = "1")
    private Long id;

    @UuidGenerator
    private UUID uuid;

    @NotBlank
    @Schema(description = "Nome do inquilino", example = "Gabriel")
    private String nome;

    @NotBlank
    @Schema(description = "Número de telefone ou email do inquilino", example = "example@email.com ou 55999009909")
    private String contato;

    @NonNull
    @Schema(description = "CPF de 11 números do inquilino", example = "08217119047")
    @Size(max = 11, min = 11, message = "cpf invalido")
    private String cpf;


}

package br.csi.gerenciador.model.inquilino;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface InquilinoRepository extends JpaRepository<Inquilino, Long>
{
    public Inquilino findInquilinoByUuid(UUID uuid);

    public void deleteInquilinoByUuid(UUID uuid);
}

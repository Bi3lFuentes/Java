package br.csi.gerenciador.model.responsavel;

import br.csi.gerenciador.model.imovel.Imovel;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;

import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "responsavel")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Responsavel {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "ID do Responsável", example = "1")
    private Long id;

    @UuidGenerator
    private UUID uuid;

    @NotBlank
    @Schema(description = "Nome do responsável", example = "Pedro")
    private String nome;

    @NotBlank
    @Schema(description = "Contato do resposável pelo imóvel", example = "55999000999")
    private String contato;

    @NotBlank
    @Schema(description = "Atribuição do responsável", example = "Limpeza")
    private String atribuicao;

    // Relacionamento N para N com Imovel
    @ManyToMany(mappedBy = "responsaveis")
    @JsonIgnoreProperties("responsaveis")
    private List<Imovel> imoveis;
}

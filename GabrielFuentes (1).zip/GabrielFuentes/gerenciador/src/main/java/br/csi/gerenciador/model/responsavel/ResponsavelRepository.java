package br.csi.gerenciador.model.responsavel;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface ResponsavelRepository extends JpaRepository<Responsavel, Long> {

    public Responsavel findResponsavelByUuid(UUID uuid);

    public void deleteResponsavelByUuid(UUID uuid);

}

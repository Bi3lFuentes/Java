package br.csi.gerenciador.model.usuario;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.*;


@Entity(name="Usuario")
@Table(name="usuarios")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NonNull
    @Email
    private String login;

    @NonNull
    private String senha;
    private String permissao;

}

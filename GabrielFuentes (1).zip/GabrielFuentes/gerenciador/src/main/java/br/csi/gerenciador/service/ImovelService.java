package br.csi.gerenciador.service;

import br.csi.gerenciador.model.imovel.Imovel;
import br.csi.gerenciador.model.imovel.ImovelRepository;
import br.csi.gerenciador.model.responsavel.Responsavel;
import br.csi.gerenciador.model.responsavel.ResponsavelRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ImovelService {

    private final ImovelRepository repository;
    private final ResponsavelRepository responsavelRepository;

    public ImovelService(ImovelRepository repository, ResponsavelRepository responsavelRepository) {
        this.repository = repository;
        this.responsavelRepository = responsavelRepository;
    }

    public void salvar(Imovel imovel) {
        repository.save(imovel);
    }

    public List<Imovel> listar() {
        return repository.findAll();
    }

    public Imovel getImovel(Long id) {
        return repository.getReferenceById(id);
    }

    public void excluir(Long id) {
        this.repository.deleteById(id);
    }

    public void atualizar(Imovel imovel) {
        Imovel imv = this.repository.getReferenceById(imovel.getId());
        imv.setId(imv.getId());
        imv.setCidade(imovel.getCidade());
        imv.setBairro(imovel.getBairro());
        imv.setRua(imovel.getRua());
        imv.setNumero(imovel.getNumero());
        imv.setComplemento(imovel.getComplemento());
        imv.setTipo(imovel.getTipo());
        imv.setQuartos(imovel.getQuartos());
        imv.setBanheiros(imovel.getBanheiros());
        imv.setVagas_garagem(imovel.getVagas_garagem());
        imv.setAlugado(imovel.isAlugado());

        this.repository.save(imovel);
    }

    public Imovel getImovelUUID(String uuid) {
        UUID uuidformatado = UUID.fromString(uuid);
        return this.repository.findImovelByUuid(uuidformatado);
    }

    public void deletarUUID(String uuid){
        this.repository.deleteImovelByUuid(UUID.fromString(uuid));
    }

    public Imovel addResponsavelToImovel(Long imovelId, Long responsavelId) {
        // Verifica se o imóvel existe
        Imovel imovel = repository.findById(imovelId)
                .orElseThrow(() -> new RuntimeException("Imóvel não encontrado com o id: " + imovelId));

        // Verifica se o responsável existe
        Responsavel responsavel = responsavelRepository.findById(responsavelId)
                .orElseThrow(() -> new RuntimeException("Responsável não encontrado com o id: " + responsavelId));

        // Adiciona o responsável à lista de responsáveis do imóvel
        imovel.getResponsaveis().add(responsavel);

        // Se necessário, adicione o imóvel à lista de imóveis do responsável
        responsavel.getImoveis().add(imovel);

        // Salva as alterações tanto no imóvel quanto no responsável
        repository.save(imovel); // Salva a associação no imóvel
        responsavelRepository.save(responsavel); // Salva a associação no responsável (caso necessário)

        return imovel;
    }

}

package br.csi.gerenciador.service;

import br.csi.gerenciador.model.inquilino.Inquilino;
import br.csi.gerenciador.model.inquilino.InquilinoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class InquilinoService {

    private final InquilinoRepository repository;

    public InquilinoService(InquilinoRepository repository) {

        this.repository = repository;
    }

    public void salvar(Inquilino inquilino) {

        this.repository.save(inquilino);
    }

    public Inquilino getInquilinoUUID(String uuid) {
        UUID uuidformatado = UUID.fromString(uuid);
        return this.repository.findInquilinoByUuid(uuidformatado);
    }


    public List<Inquilino> listar() {

        return this.repository.findAll();
    }

    public Inquilino getInquilino(Long id) {
        return repository.getReferenceById(id);}

    public void excluir(Long id) {this.repository.deleteById(id);}

 public void atualizar(Inquilino inquilino) {
        Inquilino inq = this.repository.getReferenceById(inquilino.getId());
        inq.setNome(inquilino.getNome());
        inq.setCpf(inquilino.getCpf());
        inq.setContato(inquilino.getContato());
        this.repository.save(inq);
 }

}

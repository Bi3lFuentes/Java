package br.csi.gerenciador.service;

import br.csi.gerenciador.model.responsavel.Responsavel;
import br.csi.gerenciador.model.responsavel.ResponsavelRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ResponsavelService {

    private final ResponsavelRepository repository;

    public ResponsavelService(ResponsavelRepository repository) {

        this.repository = repository;
    }

    public void salvar(Responsavel responsavel) {

        this.repository.save(responsavel);
    }

    public Responsavel getResponsavelUUID(String uuid) {
        UUID uuidformatado = UUID.fromString(uuid);
        return this.repository.findResponsavelByUuid(uuidformatado);
    }

    public List<Responsavel> listar() {

        return this.repository.findAll();
    }

    public Responsavel getResponsavel(Long id) {
        return repository.getReferenceById(id);}

    public void excluir(Long id) {
        this.repository.deleteById(id);
    }

    public void atualizar(Responsavel responsavel) {
        Responsavel resp = this.repository.getReferenceById(responsavel.getId());
        resp.setNome(responsavel.getNome());
        resp.setContato(responsavel.getContato());
        this.repository.save(resp);
    }
}

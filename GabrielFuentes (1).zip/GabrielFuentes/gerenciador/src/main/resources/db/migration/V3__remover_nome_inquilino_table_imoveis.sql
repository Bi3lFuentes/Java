ALTER TABLE Imoveis
DROP COLUMN nome_inquilino;